from django.db import models

# Create your models here.
class CandidateIssue(models.Model):
    issue = models.CharField(max_length=100)
    description = models.TextField()
    date = models.DateField(auto_now_add=True)
