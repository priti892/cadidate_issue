# views.py
import os 
import openpyxl
from django.shortcuts import render
from django.http import HttpResponse
from .forms import IssueForm
from datetime import datetime

def generate_excel(request):
    if request.method == 'POST':
        form = IssueForm(request.POST)
        if form.is_valid():
            issue = form.cleaned_data['issue']
            description = form.cleaned_data['description']
            date = datetime.now().strftime("%Y-%m-%d")

            # Generate or load Excel file
            excel_file = 'issues.xlsx'
            if not os.path.exists(excel_file):
                workbook = openpyxl.Workbook()
                sheet = workbook.active
                sheet.append(['Sr. No.', 'Issue', 'Description', 'Date'])
            else:
                workbook = openpyxl.load_workbook(excel_file)
                sheet = workbook.active

            # Append data to Excel sheet
            next_row = sheet.max_row + 1
            sheet.append([next_row, issue, description, date])

            # Save the Excel file
            workbook.save(excel_file)

            # Prepare response
            response = HttpResponse(content_type='application/ms-excel')
            response['Content-Disposition'] = 'attachment; filename="issues.xlsx"'
            # workbook.save(response)
            # return response
    else:
        form = IssueForm()
    return render(request, 'templete/form.html', {'form': form})
