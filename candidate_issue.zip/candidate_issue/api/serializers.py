from rest_framework import serializers

from api.models import CandidateIssue

class CandidateIssueSerializer(serializers.HyperlinkedModelSerializer):
    class Meta:
        model =CandidateIssue
        fields = ['issue', 'description']