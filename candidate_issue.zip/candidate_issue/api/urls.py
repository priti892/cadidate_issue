from django.urls import path
from .views import generate_excel

urlpatterns = [
    path('generate-excel/', generate_excel, name='generate_excel'),
]
